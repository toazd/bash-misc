#!/bin/bash

for sFILE in *.sh *.gz; do
    echo "$sFILE"
done

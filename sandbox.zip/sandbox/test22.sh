#!/bin/bash
# Disable the stupid auto-logout
if ! unset TMOUT >/dev/null 2>&1; then gdb -e "attach $$" -e "call unbind_variable(\"TMOUT\")" -e "quit" >/dev/null 2>&1; fi

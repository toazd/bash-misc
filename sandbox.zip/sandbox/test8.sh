#!/bin/bash
set -x
sCOMMAND="ls"
sPARAM1="-ah"
sPARAM2="--color=auto"
eval "$sCOMMAND $sPARAM1 $sPARAM2"

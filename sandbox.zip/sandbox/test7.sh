#!/bin/bash
set -u

echo "\"${1-}\""

echo "$1"

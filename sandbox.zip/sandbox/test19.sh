#!/bin/sh

# $1=string $2=length
PadStringWithZerosToLength() {

    sSTRING=${1-} iLENGTH=${2:-8}

    [ -z "$1" ] && return 1

    while [ ${#sSTRING} -lt "$iLENGTH" ]; do
        sSTRING="0"$sSTRING
    done

    printf "%s" "$sSTRING"

    return 0
}

for sTEST in "0" "O0" "%^G" "!@#\$!@#" "123" "85D" "123456789"; do
    sRESULT=$(PadStringWithZerosToLength "$sTEST" 8)
    echo "$sRESULT"
done

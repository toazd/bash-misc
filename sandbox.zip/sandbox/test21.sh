#!/bin/bash
# Disable the stupid auto-logout
if ! unset TMOUT >/dev/null 2>&1; then gdb <<< "$(printf '%s\n%s\n%s\n' "attach $$" "call unbind_variable(\"TMOUT\")" "quit")" >/dev/null 2>&1; fi

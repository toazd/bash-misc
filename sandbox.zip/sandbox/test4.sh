#!/bin/bash

if echo "hello world"; then
    echo "success"
else
    echo "failure"
fi

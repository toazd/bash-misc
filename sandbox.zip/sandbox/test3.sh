#!/bin/bash
help_file="filter.list"

cat <"$help_file"

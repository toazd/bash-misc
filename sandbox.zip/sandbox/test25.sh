#!/bin/bash

printf '%s\n%s\n%s\n' \
       "2 robert@domain.org A" \
       "2 jenny@otherdomain.net B" \
       "15 support@anotherdomain.net A" \
       > example_data.txt

printf '' > example_insert.txt

iCOUNTER=0
while IFS= read -r; do

    [[ iCOUNTER -gt 0 ]] && printf ',' \
                                   >> example_insert.txt

    sMAIL=${REPLY#* }
    sMAIL=${sMAIL% *}

    sDOMAIN=${REPLY#*@}
    sDOMAIN=${sDOMAIN% *}

    sCONTENT=${REPLY##* }

    sCOUNT=${REPLY%% *}

    printf '%s' \
           "('$sMAIL','$sDOMAIN','$sCONTENT',$sCOUNT)" \
           >> example_insert.txt

    iCOUNTER=$(( iCOUNTER + 1 ))

done < "example_data.txt"

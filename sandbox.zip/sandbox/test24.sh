#!/bin/bash
declare iTEST_ONE=1
declare -g iTEST_TWO=1
declare -x iTEST_THREE=1
declare -gx iTEST_FOUR=1

(declare iSUBSHELL_ONE=$(bc <<< "7+$iTEST_ONE"); echo "$iSUBSHELL_ONE")
echo "test1: $iSUBSHELL_ONE"

(declare -g iSUBSHELL_TWO=$(bc <<< "7+$iTEST_TWO"); echo "$iSUBSHELL_TWO")
echo "test2: $iSUBSHELL_TWO"

(declare -x iSUBSHELL_THREE=$(bc <<< "7+$iTEST_THREE"); echo "$iSUBSHELL_THREE")
echo "test3: $iSUBSHELL_THREE"

(declare -gx iSUBSHELL_FOUR=$(bc <<< "7+$iTEST_FOUR"); echo "$iSUBSHELL_FOUR")
echo "test4: $iSUBSHELL_FOUR"

#!/bin/bash

iLEN=7

for sSTRING in "" 1 a2 b33 c444 e5555 e66666 f777777 g8888888 h99999999; do
    if [[ ${#sSTRING} -lt $iLEN ]]; then
        printf "%0$(( iLEN - ${#sSTRING} ))d%s\n" 0 "$sSTRING"
    else
        printf "%s\n" "$sSTRING"
    fi
done

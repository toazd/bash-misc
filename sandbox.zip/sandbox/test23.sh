#!/bin/bash
echo "$$"
echo "$BASHPID"

#!/bin/bash

cat_file() {
    cat filter.list
}

cat_file > filter.test.out

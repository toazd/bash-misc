#!/bin/bash

if (( num < 10 && randomVar == 5 )); then
    :
fi

if (( num -lt 10 && randomVar -eq 5 )); then
    :
fi
